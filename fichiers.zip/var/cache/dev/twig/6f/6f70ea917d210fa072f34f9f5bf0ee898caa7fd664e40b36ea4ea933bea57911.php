<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* app/newBook.html.twig */
class __TwigTemplate_4521f437ccdc52de7e158b1084f59e937d4ab4d25aa59cdf899c92eb1572a820 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/newBook.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/newBook.html.twig"));

        // line 2
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme((isset($context["formNewBook"]) || array_key_exists("formNewBook", $context) ? $context["formNewBook"] : (function () { throw new RuntimeError('Variable "formNewBook" does not exist.', 2, $this->source); })()), [0 => "bootstrap_4_layout.html.twig"], true);
        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "app/newBook.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
    <h1>
        ";
        // line 7
        if ((isset($context["titlePage"]) || array_key_exists("titlePage", $context) ? $context["titlePage"] : (function () { throw new RuntimeError('Variable "titlePage" does not exist.', 7, $this->source); })())) {
            // line 8
            echo "            Modifier le livre
        ";
        } else {
            // line 10
            echo "            Créer un nouveau livre
        ";
        }
        // line 12
        echo "    </h1>
    
    <hr>

    ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formNewBook"]) || array_key_exists("formNewBook", $context) ? $context["formNewBook"] : (function () { throw new RuntimeError('Variable "formNewBook" does not exist.', 16, $this->source); })()), 'form_start');
        echo "

    ";
        // line 18
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formNewBook"]) || array_key_exists("formNewBook", $context) ? $context["formNewBook"] : (function () { throw new RuntimeError('Variable "formNewBook" does not exist.', 18, $this->source); })()), "title", [], "any", false, false, false, 18), 'row');
        echo "
    ";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formNewBook"]) || array_key_exists("formNewBook", $context) ? $context["formNewBook"] : (function () { throw new RuntimeError('Variable "formNewBook" does not exist.', 19, $this->source); })()), "content", [], "any", false, false, false, 19), 'row');
        echo "
    ";
        // line 20
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formNewBook"]) || array_key_exists("formNewBook", $context) ? $context["formNewBook"] : (function () { throw new RuntimeError('Variable "formNewBook" does not exist.', 20, $this->source); })()), "completed", [], "any", false, false, false, 20), 'row');
        echo "
    ";
        // line 21
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["formNewBook"]) || array_key_exists("formNewBook", $context) ? $context["formNewBook"] : (function () { throw new RuntimeError('Variable "formNewBook" does not exist.', 21, $this->source); })()), "public", [], "any", false, false, false, 21), 'row');
        echo "
    

    <button type=\"submit\" class=\"btn btn-success\">
        ";
        // line 25
        if ((isset($context["editMode"]) || array_key_exists("editMode", $context) ? $context["editMode"] : (function () { throw new RuntimeError('Variable "editMode" does not exist.', 25, $this->source); })())) {
            // line 26
            echo "            Modifier les détails du livre
        ";
        } else {
            // line 28
            echo "            Créer le livre
        ";
        }
        // line 30
        echo "    </button>

    ";
        // line 32
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formNewBook"]) || array_key_exists("formNewBook", $context) ? $context["formNewBook"] : (function () { throw new RuntimeError('Variable "formNewBook" does not exist.', 32, $this->source); })()), 'form_end');
        echo "

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "app/newBook.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 32,  125 => 30,  121 => 28,  117 => 26,  115 => 25,  108 => 21,  104 => 20,  100 => 19,  96 => 18,  91 => 16,  85 => 12,  81 => 10,  77 => 8,  75 => 7,  71 => 5,  61 => 4,  50 => 1,  48 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% form_theme formNewBook 'bootstrap_4_layout.html.twig' %}

{% block body %}

    <h1>
        {% if titlePage %}
            Modifier le livre
        {% else %}
            Créer un nouveau livre
        {% endif %}
    </h1>
    
    <hr>

    {{ form_start(formNewBook) }}

    {{ form_row(formNewBook.title) }}
    {{ form_row(formNewBook.content) }}
    {{ form_row(formNewBook.completed) }}
    {{ form_row(formNewBook.public) }}
    

    <button type=\"submit\" class=\"btn btn-success\">
        {% if editMode %}
            Modifier les détails du livre
        {% else %}
            Créer le livre
        {% endif %}
    </button>

    {{ form_end(formNewBook) }}

{% endblock %}", "app/newBook.html.twig", "C:\\wamp64\\www\\projet5.3\\templates\\app\\newBook.html.twig");
    }
}
