<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* app/showChapter.html.twig */
class __TwigTemplate_df8d20e9bdfa1f2121aa1052a2edd411d38a9c7bfbb7a9d81cc56352b4338a2a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/showChapter.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "app/showChapter.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "app/showChapter.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    <article>
        <h2>";
        // line 6
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 6, $this->source); })()), "title", [], "any", false, false, false, 6), "html", null, true);
        echo "</h2>
        <a class=\"btn btn-outline-secondary\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("edit_chapter", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 7, $this->source); })()), "id", [], "any", false, false, false, 7)]), "html", null, true);
        echo "\" role=\"button\">Modifier le chapitre</a>

        ";
        // line 10
        echo "        <button type=\"button\" class=\"btn btn-dark\" data-toggle=\"modal\" data-target=\"#exampleModal1\">
        Supprimer ce chapitre
        </button>

        ";
        // line 15
        echo "        <div class=\"modal fade\" id=\"exampleModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Suppression</h5>
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                <span aria-hidden=\"true\">&times;</span>
                </button>
            </div>
            <div class=\"modal-body\">
                Voulez-vous vraiment supprimer ce chapitre ? <br>
                <span class=\"badge badge-pill badge-dark\"> ";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 26, $this->source); })()), "title", [], "any", false, false, false, 26), "html", null, true);
        echo " </span>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Annuler</button>
                <a class=\"btn btn-dark\" href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_chapter", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 30, $this->source); })()), "id", [], "any", false, false, false, 30)]), "html", null, true);
        echo "\" role=\"button\">Supprimer</a>
            </div>
            </div>
        </div>
        </div>

        <div class=\"metadata\">écrit le ";
        // line 36
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 36, $this->source); })()), "publishedDate", [], "any", false, false, false, 36), "d/m/Y"), "html", null, true);
        echo " à ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 36, $this->source); })()), "publishedDate", [], "any", false, false, false, 36), "H:i"), "html", null, true);
        echo "</div>
        <hr>
        <div>";
        // line 38
        echo twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 38, $this->source); })()), "content", [], "any", false, false, false, 38);
        echo "</div>
    </article>
    <hr>

    <section id=\"commentaires\">
        <h3>";
        // line 43
        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["chapter"]) || array_key_exists("chapter", $context) ? $context["chapter"] : (function () { throw new RuntimeError('Variable "chapter" does not exist.', 43, $this->source); })()), "comments", [], "any", false, false, false, 43)), "html", null, true);
        echo " Commentaires :</h3>
        
        ";
        // line 45
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 45, $this->source); })()), "user", [], "any", false, false, false, 45)) {
            // line 46
            echo "        <p class=\"\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 46, $this->source); })()), "user", [], "any", false, false, false, 46), "username", [], "any", false, false, false, 46), "html", null, true);
            echo " vous souhaitez laisser un petit commentaire gentil à l'auteur ?</p>
        ";
            // line 47
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 47, $this->source); })()), 'form_start');
            echo "
        ";
            // line 48
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 48, $this->source); })()), 'widget');
            echo "
        <button type=\"submit\" class=\"btn btn-success\">Laisser un commentaire </button>

        ";
            // line 51
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 51, $this->source); })()), 'form_end');
            echo "
        ";
        } else {
            // line 53
            echo "            <span class=\"badge badge-pill badge-dark\">Vous ne pouvez pas laisser de commentaires, tant que vous n'êtes pas connecté.</span>
            <a class=\"btn btn-outline-secondary\" href=\"";
            // line 54
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("security_login");
            echo "\" role=\"button\">Connectez-vous</a>
        ";
        }
        // line 56
        echo "
        ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["comments"]) || array_key_exists("comments", $context) ? $context["comments"] : (function () { throw new RuntimeError('Variable "comments" does not exist.', 57, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 58
            echo "            <div class=\"comment\">
            <span class=\"badge badge-pill badge-dark\">";
            // line 59
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 59), "html", null, true);
            echo "</span>
            <span class=\"badge badge-pill badge-light\">";
            // line 60
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "createdAt", [], "any", false, false, false, 60), "d/m/Y à H:i"), "html", null, true);
            echo "</span>
            <p>";
            // line 61
            echo twig_get_attribute($this->env, $this->source, $context["comment"], "content", [], "any", false, false, false, 61);
            echo "</p>
            ";
            // line 62
            if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 62, $this->source); })()), "user", [], "any", false, false, false, 62)) {
                // line 63
                echo "                ";
                if ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 63, $this->source); })()), "user", [], "any", false, false, false, 63), "username", [], "any", false, false, false, 63) === twig_get_attribute($this->env, $this->source, $context["comment"], "author", [], "any", false, false, false, 63))) {
                    // line 64
                    echo "                    <a class=\"btn btn-outline-secondary\" href=\"";
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("edit_comment", ["id" => twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 64)]), "html", null, true);
                    echo "\" role=\"button\">Modifier le commentaire</a>

                    ";
                    // line 67
                    echo "                    <button type=\"button\" class=\"btn btn-dark\" data-toggle=\"modal\" data-target=\"#exampleModal2-";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 67), "html", null, true);
                    echo "\">
                    Supprimer ";
                    // line 68
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 68), "html", null, true);
                    echo "
                    </button>

                    ";
                    // line 72
                    echo "                    <div class=\"modal fade\" id=\"exampleModal2-";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 72), "html", null, true);
                    echo "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
                    <div class=\"modal-dialog\" role=\"document\">
                        <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <h5 class=\"modal-title\" id=\"exampleModalLabel\">Suppression</h5>
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                            <span aria-hidden=\"true\">&times;</span>
                            </button>
                        </div>
                        <div class=\"modal-body\">
                            Voulez-vous vraiment supprimer ce commentaire ?
                            <br><br>
                            <p>\" ";
                    // line 84
                    echo twig_get_attribute($this->env, $this->source, $context["comment"], "content", [], "any", false, false, false, 84);
                    echo " \"</p>
                        </div>
                        <div class=\"modal-footer\">
                            <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Annuler</button>
                            <a class=\"btn btn-dark\" href=\"";
                    // line 88
                    echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_comment", ["id" => twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 88)]), "html", null, true);
                    echo "\" role=\"button\">Supprimer</a>
                        </div>
                        </div>
                    </div>
                    </div>

                ";
                }
                // line 95
                echo "            ";
            }
            // line 96
            echo "
            <br><br><br>
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "    </section>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "app/showChapter.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  254 => 100,  245 => 96,  242 => 95,  232 => 88,  225 => 84,  209 => 72,  203 => 68,  198 => 67,  192 => 64,  189 => 63,  187 => 62,  183 => 61,  179 => 60,  175 => 59,  172 => 58,  168 => 57,  165 => 56,  160 => 54,  157 => 53,  152 => 51,  146 => 48,  142 => 47,  137 => 46,  135 => 45,  130 => 43,  122 => 38,  115 => 36,  106 => 30,  99 => 26,  86 => 15,  80 => 10,  75 => 7,  71 => 6,  68 => 5,  58 => 4,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}


{% block body %}
    <article>
        <h2>{{ chapter.title }}</h2>
        <a class=\"btn btn-outline-secondary\" href=\"{{ path('edit_chapter', {'id': chapter.id }) }}\" role=\"button\">Modifier le chapitre</a>

        {#<!-- Button trigger modal -->#}
        <button type=\"button\" class=\"btn btn-dark\" data-toggle=\"modal\" data-target=\"#exampleModal1\">
        Supprimer ce chapitre
        </button>

        {#<!-- Modal -->#}
        <div class=\"modal fade\" id=\"exampleModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"exampleModalLabel\">Suppression</h5>
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                <span aria-hidden=\"true\">&times;</span>
                </button>
            </div>
            <div class=\"modal-body\">
                Voulez-vous vraiment supprimer ce chapitre ? <br>
                <span class=\"badge badge-pill badge-dark\"> {{ chapter.title }} </span>
            </div>
            <div class=\"modal-footer\">
                <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Annuler</button>
                <a class=\"btn btn-dark\" href=\"{{ path('delete_chapter', {'id': chapter.id }) }}\" role=\"button\">Supprimer</a>
            </div>
            </div>
        </div>
        </div>

        <div class=\"metadata\">écrit le {{ chapter.publishedDate | date('d/m/Y') }} à {{ chapter.publishedDate | date('H:i') }}</div>
        <hr>
        <div>{{ chapter.content | raw }}</div>
    </article>
    <hr>

    <section id=\"commentaires\">
        <h3>{{ chapter.comments | length }} Commentaires :</h3>
        
        {% if app.user %}
        <p class=\"\">{{ app.user.username }} vous souhaitez laisser un petit commentaire gentil à l'auteur ?</p>
        {{ form_start(commentForm) }}
        {{ form_widget(commentForm) }}
        <button type=\"submit\" class=\"btn btn-success\">Laisser un commentaire </button>

        {{ form_end(commentForm) }}
        {% else %}
            <span class=\"badge badge-pill badge-dark\">Vous ne pouvez pas laisser de commentaires, tant que vous n'êtes pas connecté.</span>
            <a class=\"btn btn-outline-secondary\" href=\"{{ path('security_login') }}\" role=\"button\">Connectez-vous</a>
        {% endif %}

        {% for comment in comments %}
            <div class=\"comment\">
            <span class=\"badge badge-pill badge-dark\">{{ comment.author }}</span>
            <span class=\"badge badge-pill badge-light\">{{ comment.createdAt | date('d/m/Y à H:i')}}</span>
            <p>{{ comment.content | raw }}</p>
            {% if app.user %}
                {% if app.user.username is same as(comment.author) %}
                    <a class=\"btn btn-outline-secondary\" href=\"{{ path('edit_comment', {'id': comment.id }) }}\" role=\"button\">Modifier le commentaire</a>

                    {#<!-- Button trigger modal -->#}
                    <button type=\"button\" class=\"btn btn-dark\" data-toggle=\"modal\" data-target=\"#exampleModal2-{{ comment.id }}\">
                    Supprimer {{ comment.id }}
                    </button>

                    {#<!-- Modal -->#}
                    <div class=\"modal fade\" id=\"exampleModal2-{{ comment.id }}\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
                    <div class=\"modal-dialog\" role=\"document\">
                        <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <h5 class=\"modal-title\" id=\"exampleModalLabel\">Suppression</h5>
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                            <span aria-hidden=\"true\">&times;</span>
                            </button>
                        </div>
                        <div class=\"modal-body\">
                            Voulez-vous vraiment supprimer ce commentaire ?
                            <br><br>
                            <p>\" {{ comment.content | raw }} \"</p>
                        </div>
                        <div class=\"modal-footer\">
                            <button type=\"button\" class=\"btn btn-secondary\" data-dismiss=\"modal\">Annuler</button>
                            <a class=\"btn btn-dark\" href=\"{{ path('delete_comment', {'id': comment.id }) }}\" role=\"button\">Supprimer</a>
                        </div>
                        </div>
                    </div>
                    </div>

                {% endif %}
            {% endif %}

            <br><br><br>
            </div>
        {% endfor %}
    </section>
{% endblock %}", "app/showChapter.html.twig", "C:\\wamp64\\www\\projet5.3\\templates\\app\\showChapter.html.twig");
    }
}
