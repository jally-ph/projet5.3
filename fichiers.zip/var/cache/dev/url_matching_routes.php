<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/app' => [[['_route' => 'app', '_controller' => 'App\\Controller\\AppController::index'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'home', '_controller' => 'App\\Controller\\AppController::home'], null, null, null, false, false, null]],
        '/categories' => [[['_route' => 'categories', '_controller' => 'App\\Controller\\AppController::categoryPage'], null, null, null, false, false, null]],
        '/app/newbook' => [[['_route' => 'new_book', '_controller' => 'App\\Controller\\AppController::newBook'], null, null, null, false, false, null]],
        '/inscription' => [[['_route' => 'security_registration', '_controller' => 'App\\Controller\\SecurityController::registration'], null, null, null, false, false, null]],
        '/connexion' => [[['_route' => 'security_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/deconnexion' => [[['_route' => 'security_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/c(?'
                    .'|ategory/([^/]++)(*:190)'
                    .'|hapter/([^/]++)(*:213)'
                .')'
                .'|/app/(?'
                    .'|newchapter/([^/]++)(*:249)'
                    .'|([^/]++)(*:265)'
                .')'
                .'|/edit(?'
                    .'|c(?'
                        .'|omment/([^/]++)(*:301)'
                        .'|hapter/([^/]++)(*:324)'
                    .')'
                    .'|book/([^/]++)(*:346)'
                .')'
                .'|/delete/(?'
                    .'|c(?'
                        .'|omment/([^/]++)(*:385)'
                        .'|hapter/([^/]++)(*:408)'
                    .')'
                    .'|book/([^/]++)(*:430)'
                .')'
                .'|/search/([^/]++)(*:455)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        190 => [[['_route' => 'show_category', '_controller' => 'App\\Controller\\AppController::getCategory'], ['category'], null, null, false, true, null]],
        213 => [[['_route' => 'chapter_show', '_controller' => 'App\\Controller\\AppController::showChapter'], ['id'], null, null, false, true, null]],
        249 => [[['_route' => 'new_chapter', '_controller' => 'App\\Controller\\AppController::newChapter'], ['id'], null, null, false, true, null]],
        265 => [[['_route' => 'app_show', '_controller' => 'App\\Controller\\AppController::showBook'], ['id'], null, null, false, true, null]],
        301 => [[['_route' => 'edit_comment', '_controller' => 'App\\Controller\\AppController::editComment'], ['id'], null, null, false, true, null]],
        324 => [[['_route' => 'edit_chapter', '_controller' => 'App\\Controller\\AppController::editChapter'], ['id'], null, null, false, true, null]],
        346 => [[['_route' => 'edit_book', '_controller' => 'App\\Controller\\AppController::editBook'], ['id'], null, null, false, true, null]],
        385 => [[['_route' => 'delete_comment', '_controller' => 'App\\Controller\\AppController::deleteComment'], ['id'], null, null, false, true, null]],
        408 => [[['_route' => 'delete_chapter', '_controller' => 'App\\Controller\\AppController::deleteChapter'], ['id'], null, null, false, true, null]],
        430 => [[['_route' => 'delete_book', '_controller' => 'App\\Controller\\AppController::deleteBook'], ['id'], null, null, false, true, null]],
        455 => [
            [['_route' => 'search', '_controller' => 'App\\Controller\\SecurityController::search'], ['search'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
